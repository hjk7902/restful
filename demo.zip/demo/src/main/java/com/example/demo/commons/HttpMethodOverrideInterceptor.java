package com.example.demo.commons;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class HttpMethodOverrideInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String methodOverride = request.getHeader("X-HTTP-Method-Override");
        System.out.println(methodOverride);
        // X-HTTP-Method-Override 헤더가 존재하면 해당 메서드로 오버라이드
        if (methodOverride != null && !methodOverride.isEmpty()) {
            // request 객체의 메서드를 오버라이드
            HttpServletRequestWrapper wrapper = new HttpServletRequestWrapper(request) {
                @Override
                public String getMethod() {
                    return methodOverride;
                }
            };
            request = wrapper;
        }
        return true;  // 다음 인터셉터 또는 컨트롤러로 요청을 전달
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        // postHandle에서는 아무 작업도 하지 않음
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        // afterCompletion에서는 아무 작업도 하지 않음
    }
}
