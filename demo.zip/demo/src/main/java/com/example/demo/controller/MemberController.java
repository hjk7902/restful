package com.example.demo.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Member;
import com.example.demo.model.MemberModelAssembler;
import com.example.demo.service.MemberService;

@RestController
@RequestMapping("/api/members")
public class MemberController {

    @Autowired
    private MemberService memberService;
    
    @Autowired
    private MemberModelAssembler assembler;
    
    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<Member>>> getAllMembers() {
        List<EntityModel<Member>> members = memberService.getAllMembers().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return ResponseEntity.ok(
                CollectionModel.of(members,
                        linkTo(methodOn(MemberController.class).getAllMembers()).withSelfRel()));
    }
    

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<Member>> getMemberById(@PathVariable Long id) {
        Optional<Member> member = memberService.getMemberById(id);

        // Optional에서 Member 객체가 존재하는지 확인
        if (member.isPresent()) {
            EntityModel<Member> entityModel = assembler.toModel(member.get());
            return ResponseEntity.ok(entityModel);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
//
//    // 특정 사용자 조회
//    @GetMapping("/{id}")
//    public ResponseEntity<Member> getMemberById(@PathVariable Long id) {
//        Optional<Member> member = memberService.getMemberById(id);
//        // Optional에 값이 있는지 확인하고, 없다면 404 Not Found 응답을 반환
//        if (member.isPresent()) {
//            return ResponseEntity
//                    .ok()
//                    .eTag("\"" + member.get().hashCode() + "\"")
//                    .body(member.get()); // Optional에서 Member 객체를 추출하여 반환
//        } else {
//            return ResponseEntity.notFound().build(); // 값이 없을 경우 404 Not Found 응답을 반환
//        }
////        return member.map(ResponseEntity::ok)
////                .orElseGet(() -> ResponseEntity.notFound().build());
//    }

    // 새 사용자 생성
    @PostMapping
    public Member createMember(@RequestBody Member member) {
        return memberService.createMember(member);
    }

    // 사용자 정보 업데이트
    @PutMapping("/{id}")
    public ResponseEntity<Member> updateMember(@PathVariable Long id, @RequestBody Member memberDetails) {
        Optional<Member> updatedMember = memberService.updateMember(id, memberDetails);
        return updatedMember.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 사용자 삭제
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMember(@PathVariable Long id) {
        if (memberService.deleteMember(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
